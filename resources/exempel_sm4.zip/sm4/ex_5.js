function newLink(){
  // Skapa ett nytt element och en tillh�rande textnod
  var link_to_lms = document.createElement("a");
  link_to_lms.href = "http://www.mah.se/lms";
  var link_to_lms_textnode = document.createTextNode("L�nk till LMS");

  // L�gg till textnoden till elementet
  link_to_lms.appendChild(link_to_lms_textnode);

  // Skapa ett nytt listitem-element
  var new_list_item = document.createElement("li");

  // l�gg in den mya l�nken i listitem-elementet
  new_list_item.appendChild(link_to_lms);

  //L�gg till elementet sist i listan
  document.getElementById("dyn_list").appendChild(new_list_item);
}

/*
 * F�r att vi ska slippa s� m�nga alertrutor och �nd� h�lla oss till korrekt 
 * W3C-standard f�r DOM och h�ndelsehantering s� kr�vs lite trick
 * som vi �nnu inte g�tt igenom p� kursen.
 * S� d�rf�r st�r den f�r exemplet intressanta koden i funktionen example()
 * och vi beh�ver biblioteksfunktionerna newLine och addEvent. 
 * Du hittar biblioteksfunktionerna i filen library_study_material.js
 * om du �r intresserad och inte vill v�nta.
 */

function example(){
  //Pausar innan vi �ndrar l�nken s� �ndringen blir synlig
  setTimeout("newLink()", 3000);
}

addEvent(window, "load", example);