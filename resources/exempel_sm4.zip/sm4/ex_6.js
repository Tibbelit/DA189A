function createAndRemoveLink(){
  // Skapa ett nytt element och en tillh�rande textnod
  var link_to_lms = document.createElement("a");
  link_to_lms.href = "http://www.mah.se/lms";
  var link_to_lms_textnode = document.createTextNode("L�nk till LMS");

  // L�gg till textnoden till elementet
  link_to_lms.appendChild(link_to_lms_textnode);

  //L�gg till elementet sist i stycket
  document.getElementById("dyn_paragraph").appendChild(link_to_lms);

  alert("N�r du klickat OK s� kommer den nya l�nken att tas bort igen.");

  // Ta bort ett element
  link_to_lms.parentNode.removeChild(link_to_lms);
}

/*
 * F�r att vi ska slippa s� m�nga alertrutor och �nd� h�lla oss till korrekt 
 * W3C-standard f�r DOM och h�ndelsehantering s� kr�vs lite trick
 * som vi �nnu inte g�tt igenom p� kursen.
 * S� d�rf�r st�r den f�r exemplet intressanta koden i funktionen example()
 * och vi beh�ver biblioteksfunktionerna newLine och addEvent. 
 * Du hittar biblioteksfunktionerna i filen library_study_material.js
 * om du �r intresserad och inte vill v�nta.
 */

function example(){
  //Pausar innan vi �ndrar l�nken s� �ndringen blir synlig
  setTimeout("createAndRemoveLink()", 3000);
}

addEvent(window, "load", example);