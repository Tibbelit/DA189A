function example(){
  var testNode = document.getElementById("content");
  for(var i=0; i<testNode.childNodes.length; i++){
    var typeNbr = testNode.childNodes[i].nodeType;
    /* Anv�nd denna switchsats i Firefox f�r att se att konstanterna fungerar d�r*/
    /*
    switch(typeNbr){
	  case Node.ELEMENT_NODE:
      type_text = "Node "+i+" is an element node";
        break;
      case Node.TEXT_NODE:
        type_text = "Node "+i+" is a text node";
        break;
      case Node.COMMENT_NODE:
        type_text = "Node "+i+" is a comment node";
        break;
      default:
        type_text = "No match found for node "+i;
        break;
	}
	 */
 /* Anv�nd switchsatsen nedan f�r IE d� denna inte implementerar konstanterna */

    switch(typeNbr){
	  case 1:  //element node
      type_text = "Node "+i+" is an element node";
        break;
      case 3:  //text node
        type_text = "Node "+i+" is a text node";
        break;
      case 8: //comment node
        type_text = "Node "+i+" is a comment node";
        break;
      default:
        type_text = "No match found for node "+i;
        break;
	}

    newLine("result", type_text);
  }
}

addEvent(window, "load", example);