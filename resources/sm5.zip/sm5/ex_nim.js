var minSticks = 5; //the smallest number of stick in a pile when a game starts
var maxSticks = 15; //the largest number of stick in a pile when a game starts
var piles = Array(3); //to keep track of number of sticks in piles
var currentPlayer=0;

/*
 * This funktion assigns a number of sticks to each pile and update the 
 * pile user interface accordingly.
 */
function initPiles(){
  var currentPile;
  for(i=0; i<3; i++){ //for all piles
    piles[i] = Math.floor((Math.random()*(maxSticks-minSticks+1))+minSticks);

    currentPile = document.getElementById("pile"+(i+1));
    if(currentPile!=null){
	  removeAllChildren(currentPile); //remove possible old cells
      for(j=1; j<=piles[i]; j++){ //create new cells to represent sticks
	    newStick = document.createElement("td");
        stick = document.createTextNode("stick "+j);
        newStick.appendChild(stick);
        currentPile.appendChild(newStick);
        newStick.id = "stick"+i+j;
        addEvent(newStick, "click", takeSticks, false);
	  }
	}
  }
}

/*
 * Given the id for an table cell representing a stick
 * the sticks pile number is extracted.
 *
 * stickId: the id of the table cell element on the form stick[pileNbr][stickNbr]
 */
function getPileNbr(stickId){
  return parseInt(stickId.charAt(5));
}

/*
 * Given the id for an table cell representing a stick
 * the sticks number is extracted.
 *
 * stickId: the id of the table cell element on the form stick[pileNbr][stickNbr]
 */
function getStickNbr(stickId){
  return parseInt(stickId.substring(6));
}

/*
 * Checks wich radiobutton that is checked and returns the corresponding
 * number of sticks to pick in next round.
 * 
 * return: 1 or 2
 */
function getNbrSticksToPick(){
  var rdb1 = document.getElementById("rdb1");
  if(rdb1.checked == true){
    return 1;
  }
  else{
    return 2;
  }
}

/*
 * Given a pile number the first not picked stick is located
 * and the corresponding table cell element is returned.
 * 
 * return: the first not picket cell or null if all sticks in the pile are picked
 */
function findNextToPick(fromPile){
  var offset = 1;
  var checkId = "stick"+fromPile+offset;
  var checkCell = document.getElementById(checkId);
  while(checkCell!=null){
    if(checkCell.className != "picked"){
	  return checkCell; //if a not picked stick was found
	}
    offset++;
    checkId = "stick"+fromPile+offset;
    checkCell = document.getElementById(checkId);
  }
  return null;
}

/*
 * Checks if all piles are empty of sticks.
 * 
 * return: true if all sticks have been picked else false
 */
function checkIfWinner(){
  return((piles[0]<=0)&&(piles[1]<=0)&&(piles[2]<=0));
}

/*
 * Notifies the user of a winner.
 */
function gameOver(){
  resultElement = document.getElementById("gameResult");
  removeAllChildren(resultElement);
  newLine("gameResult", "Vinnare �r spelare "+(currentPlayer+1));
}

/*
 * Event function that is attached to table cells representing sticks. 
 * When a stick is picked the listner is removed from that cell. 
 * If two sticks are to be picked the first not picked stick/cell in the pile/table
 * is taken as well as the one that was clicked. If two sticks should be picked 
 * but only one is free just one stick is picked.
 * If all piles are empty the current player is the winner.
 * The current player is changed.
 */
function takeSticks(e){
  //var eventObject = getEventObject(e);
  //var clickedCell = getEventTarget(eventObject);
  if(!e.target){
    alert("IE");
  }
else{alert("moz");}
var clickedCell;
  if (e.target)  // DOM
          clickedCell = e.target;
       else if (e.srcElement)  // IE
          clickedCell = e.srcElement;


  var pileNbr = getPileNbr(clickedCell.id);
  var stickNbr = getStickNbr(clickedCell.id);
  var nbrOfSticks = getNbrSticksToPick();
  var cell2 = null;
  var won = false;

  piles[pileNbr] = piles[pileNbr]-nbrOfSticks; //decrease the number of sticks in the pile

  clickedCell.className="picked";
  removeEvent(clickedCell, "click", takeSticks, false);
  if(nbrOfSticks==2){ //if pick two sticks
    cell2 = findNextToPick(pileNbr);
    if(cell2 !=null){
	  cell2.className = "picked";
      removeEvent(cell2, "click", takeSticks, false);
	}
  }

  won = checkIfWinner();

  if(won){
	gameOver();
  }
  else{
    currentPlayer = ((currentPlayer+1)%2);
    displayCurrentPlayer()
  }
}

/*
 * Displays wich is the current player.
 */
function displayCurrentPlayer(){
  curPlayerInfo = document.getElementById("currentPlayer");
  removeAllChildren(curPlayerInfo);
  newLine("currentPlayer", "Aktuell spelare �r Spelare nr "+(currentPlayer+1));
}

/*
 * Resets the variables for a new game.
 */
function newGame(){
  piles = Array(3);
  currentPlayer = 0;
  initPiles();
  displayCurrentPlayer();
  resultElement = document.getElementById("gameResult");
  removeAllChildren(resultElement); //if there was a previous game remove the result
}

/*
 * Adds listners to other elements than the tabale cells that represent sticks.
 */
function addListners(){
  element = document.getElementById("btnNewGame");
  addEvent(element, "click", newGame, false);
}


addEvent(window, "load", newGame, false);
addEvent(window, "load", addListners, false);
