function checkType(e){
  if(!e){
    alert("IE och event handler");
  }
  else if(e.srcElement){
    alert("IE och event listner");
  }
  else if(e && !e.srcElement){
    alert("DOM event handler eller listner");
  }
}


function addListners(){
  element = document.getElementById("ev_listner");
  addEvent(element, "click", checkType, false);
}

function addHandlers(){
  element = document.getElementById("ev_handler");
  element.onclick = checkType;
}


addEvent(window, "load", addHandlers, false);
addEvent(window, "load", addListners, false);
