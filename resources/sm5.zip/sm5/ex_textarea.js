function getPressedKey(e){
  eventObject = getEventObject(e);
  var key = eventObject.keyCode;
  //alert("Du tryckte p�: " + String.fromCharCode(key));
  newLine("keysPressed", "Du tryckte p�: " + String.fromCharCode(key));
}

function addListeners() {
  var textarea = document.getElementById("active_ta");
  //Anropa egen funktion 
  addEvent(textarea, "keyup", getPressedKey, false);
}

//Anv�nd egen funktion f�r load...
addEvent(window, "load", addListeners, false);