/*
 * This library file contains functions to ease the use of correct 
 * DOM usage.
 */

/*
 * This funktion appends the given text message 
 * as a new TextNode into the element with the name
 * given as the parameter insertInto.
 * A new break-element is also inserted after the 
 * new TextNode.
 */
function newLine(insertInto, message){
  var insertInElement = document.getElementById(insertInto);
  newText = document.createTextNode(message);
  insertInElement.appendChild(newText);
  newBreak = document.createElement("br");
  insertInElement.appendChild(newBreak);
}

function removeAllChildren(fromElement){
  while(fromElement.firstChild != null){
    fromElement.removeChild(fromElement.firstChild);	
  }
}