//globala variabler
var nbr1 = 0;
var nbr2 = 0;
var question = "";

function newQuestion(){
  nbr1 = Math.floor((Math.random()*9)+1);
  nbr2 = Math.floor((Math.random()*9)+1);
  question = "Hur mycket �r "+nbr1+" g�nger "+nbr2+" ?"
  return parseInt(prompt(question, ""));
}

/*
 * F�r att vi ska slippa s� m�nga alertrutor och �nd� h�lla oss till korrekt 
 * W3C-standard f�r DOM och h�ndelsehantering s� kr�vs lite trick
 * som vi �nnu inte g�tt igenom p� kursen.
 * S� d�rf�r st�r den f�r exemplet intressanta koden i funktionen example()
 * och vi beh�ver biblioteksfunktionerna newLine och addEvent. 
 * Du hittar biblioteksfunktionerna i filen library_study_material.js
 * om du �r intresserad och inte vill v�nta.
 */
function example(){
  var anotherQuestion = true;
  var answer = 0;
  while(anotherQuestion){
    answer = newQuestion();
    if(answer==(nbr1*nbr2)){
      alert("Bra, det �r r�tt!");
    }
    else{
      do{
        tryAgain = confirm("Det �r tyv�rr fel. Vill du pr�va igen?")
        if(tryAgain){
          answer = parseInt(prompt(question, ""));
		}
      }while(tryAgain && (answer!=(nbr1*nbr2)));

      if(answer==(nbr1*nbr2)){
        alert("Bra, det �r r�tt!");
      }
    }
    anotherQuestion = confirm("Vill du f� en ny fr�ga?");
  }
}

addEvent(window, "load", example);