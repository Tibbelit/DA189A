function throwCoin(){
  var random = Math.floor((Math.random()*(2)));
  if(random==1){
    return false; //krona
  }
  else{
    return true; //klave
  }
}

/*
 * F�r att vi ska slippa s� m�nga alertrutor och �nd� h�lla oss till korrekt 
 * W3C-standard f�r DOM och h�ndelsehantering s� kr�vs lite trick
 * som vi �nnu inte g�tt igenom p� kursen.
 * S� d�rf�r st�r den f�r exemplet intressanta koden i funktionen example()
 * och vi beh�ver biblioteksfunktionerna newLine och addEvent. 
 * Du hittar biblioteksfunktionerna i filen library_study_material.js
 * om du �r intresserad och inte vill v�nta.
 */
function example(){
  var nbrKlave = 0;
  var nbrKrona = 0;
  for(i=0; i<10; i++){
    var klave = throwCoin();
    if(klave){
      newLine("mainText", "Kast nr "+(i+1)+" blev klave");
      nbrKlave++;
    }
    else{
      newLine("mainText", "Kast nr "+(i+1)+" blev krona");
      nbrKrona++;
    }
  }
  newLine("mainText", "Det blev krona "+nbrKrona+" g�nger.");
  newLine("mainText", "Det blev klave "+nbrKlave+" g�nger.");
}

addEvent(window, "load", example);