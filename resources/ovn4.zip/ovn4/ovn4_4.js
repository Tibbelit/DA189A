//globala variabler
var nbr1 = 0;
var nbr2 = 0;
var answer = 0;
var question = "";

function newQuestion(){
  nbr1 = Math.floor((Math.random()*9)+1);
  nbr2 = Math.floor((Math.random()*9)+1);
  question = "Hur mycket �r "+nbr1+" g�nger "+nbr2+" ?"
  answer = parseInt(prompt(question, ""));
}

function correctAnswer(){
  i = Math.floor((Math.random()*4)+1);
  switch(i){
    case 1: alert("Bra, det �r r�tt!");
            break;
    case 2: alert("Du svarade r�tt!");
            break;
    case 3: alert("Duktigt, r�tt svar!");
            break;
    case 4: alert("Svaret �r r�tt!");
            break;
  }
}

/*
 * F�r att vi ska slippa s� m�nga alertrutor och �nd� h�lla oss till korrekt 
 * W3C-standard f�r DOM och h�ndelsehantering s� kr�vs lite trick
 * som vi �nnu inte g�tt igenom p� kursen.
 * S� d�rf�r st�r den f�r exemplet intressanta koden i funktionen example()
 * och vi beh�ver biblioteksfunktionerna newLine och addEvent. 
 * Du hittar biblioteksfunktionerna i filen library_study_material.js
 * om du �r intresserad och inte vill v�nta.
 */
function example(){
  var anotherQuestion = true;
  while(anotherQuestion){
    newQuestion();
    if(answer==(nbr1*nbr2)){
      correctAnswer();
    }
    else{
      do{
        i = Math.floor((Math.random()*4)+1);
        switch(i){
          case 1: tryAgain = confirm("Det �r tyv�rr fel.\nVill du pr�va igen.");
                  break;
          case 2: tryAgain = confirm("Det var inte r�tt svar.\nVill du pr�va igen.");
                  break;
          case 3: tryAgain = confirm("Du svarade inte r�tt.\nVill du fr�gan igen.");
                  break;
          case 4: tryAgain = confirm("Svaret st�mmer inte.\nVill du fr�gan igen.");
                  break;
        }
        if(tryAgain){
          answer = parseInt(prompt(question, ""));
        }
      }while(tryAgain && (answer!=(nbr1*nbr2)));

      if(answer==(nbr1*nbr2)){
        correctAnswer();
      }
    } //end else 
    anotherQuestion = confirm("Vill du f� en ny fr�ga?");
  } //end  while(anotherQuestion){
}

addEvent(window, "load", example);