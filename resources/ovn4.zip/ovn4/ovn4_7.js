//globala variabler
var bookings = new Array(10); //0=ledig plats, 1=bokad

//nollst�ll array d� denna inneh�ller v�rden som �r undefined
for(i=0; i<10; i++){
  bookings[i] = 0;
}

function freeInClass1(){
  var nbrBooked = 0;
  for(i=0; i<5; i++){
    if(bookings[i] == 0){
      nbrBooked++;
    }
  }
  return nbrBooked;
}

function firstFreeIndexInClass1(){
  var nbrBooked = 0;
  for(i=0; i<5; i++){
    if(bookings[i] == 0){
    return i;
    }
  }
  return i;
}

function firstFreeIndexInClass2(){
  var nbrBooked = 0;
  for(i=5; i<10; i++){
    if(bookings[i] == 0){
      return i;
    }
  }
  return i;
}

function freeInClass2(){
  var nbrBooked = 0;
  for(i=5; i<10; i++){
    if(bookings[i] == 0){
      nbrBooked++;
    }
  }
  return nbrBooked;
}

function updateTable(){
  for(i=0; i<10;i++){
    var insertInElement = document.getElementById("array"+i);
    currentChild = insertInElement.firstChild;
    if(bookings[i]==0){
      newText = document.createTextNode("ledig");
    }
    else{
      newText = document.createTextNode("bokad");
    }
    insertInElement.replaceChild(newText, currentChild);
  }//end for
}

/*
 * F�r att vi ska slippa s� m�nga alertrutor och �nd� h�lla oss till korrekt
 * W3C-standard f�r DOM och h�ndelsehantering s� kr�vs lite trick
 * som vi �nnu inte g�tt igenom p� kursen.
 * S� d�rf�r st�r den f�r exemplet intressanta koden i funktionen example()
 * och vi beh�ver biblioteksfunktionerna newLine och addEvent.
 * Du hittar biblioteksfunktionerna i filen library_study_material.js
 * om du �r intresserad och inte vill v�nta.
 */
function example(){
  var newBooking = true;
  while(newBooking){
    var classToBook = parseInt(prompt("I vilken klass vill du boka", ""));
    var nbrSeats = parseInt(prompt("Hur m�nga platser vill du boka", ""));
    if(classToBook==1){
      if(nbrSeats<=freeInClass1()){ //tillr�ckligt med platser i f�rsta
        startAt = firstFreeIndexInClass1();
        for(i=startAt; i<(nbrSeats+startAt); i++){
          bookings[i] = 1;
        }
      }
      else{ //ej tillr�ckligt med platser i f�rsta
        in1st = freeInClass1();
        in2nd = nbrSeats-in1st;
        if(in2nd<=freeInClass2()){//om platser finns i andra klass
          book = confirm("Alla fick inte plats i f�rsta klass.\nVill du boka resten i andra klass?");
          if(book){ //boka i tv� klasser
            startAt = firstFreeIndexInClass1();
            for(i=startAt; i<(in1st+startAt); i++){
              bookings[i] = 1;
            }
            startAt = firstFreeIndexInClass2();
            for(i=startAt; i<(in2nd+startAt); i++){
              bookings[i] = 1;
            }
            alert("Bokningen �r f�rdelad �ver b�gge klasserna.");
  		  }
          else{ //vill inte boka i tv� klasser
            alert("Ingen bokning har skett.");
          }
        }
        else{ //det fanns inte tillr�ckligt med platser f�r att boka
          alert("F�r f� platser lediga. Bokningen kunde inte utf�ras.");
        }
      } //end else ej tillr�ckligt med platser i f�rsta
    } //end if boka i f�rsta klass
    else{ //boka i andra klass
      if(nbrSeats<=freeInClass2()){ //tillr�ckligt med lediga platser i andra klass
        startAt = firstFreeIndexInClass2();
        for(i=startAt; i<(nbrSeats+startAt); i++){
          bookings[i] = 1;
        }
      }
      else{ //ej tillr�ckligt med platser i andra
        in2nd = freeInClass2();
        in1st = nbrSeats-in2nd;
        if(in1st<=freeInClass1()){//om platser finns i f�rsta klass
          book = confirm("Alla fick inte plats i andra klass.\nVill du boka resten i f�rsta klass?");
          if(book){ //om boka i tv� klasser
            startAt = firstFreeIndexInClass2();
            for(i=startAt; i<(in2nd+startAt); i++){
              bookings[i] = 1;
            }
            startAt = firstFreeIndexInClass1();
            for(i=startAt; i<(in1st+startAt); i++){
              bookings[i] = 1;
            }
            alert("Bokningen �r f�rdelad �ver b�gge klasserna.");
          }//end om boka i tv� klasser
          else{ //vill inte boka i tv� klasser
            alert("Ingen bokning har skett.");
          }
        }//end platser i f�rsta klass finns
        else{ //det fanns inte tillr�ckligt med platser f�r att boka
          alert("F�r f� platser lediga. Bokningen kunde inte utf�ras.");
        }
      }// end else ej tillr�ckligt med platser i andra
    }// end //boka i andra klass
    updateTable();
    newBooking = confirm("Vill du g�ra en ny bokning?");
  }//end while new booking
}//end function example

addEvent(window, "load", example);