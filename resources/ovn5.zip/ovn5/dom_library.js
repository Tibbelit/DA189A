/*
 * This library file contains functions to ease the use of correct 
 * DOM usage.
 */

/*
 * This funktion appends the given text message 
 * as a new TextNode into the element with the name
 * given as the parameter insertInto.
 * A new break-element is also inserted after the 
 * new TextNode.
 *
 * insertInto: the objekt in wich to insert the new text node.
 * message: the text for the textnode
 */
function newLine(insertInto, message){
  var insertInElement = document.getElementById(insertInto);
  newText = document.createTextNode(message);
  insertInElement.appendChild(newText);
  newBreak = document.createElement("br");
  insertInElement.appendChild(newBreak);
}

/*
 * This funktion replace all childre (previous text) with 
 * the given text for a element.
 * A new break-element is also inserted after the
 * new TextNode.
 *
 * setTextTo: the objekt tht is to contain the new text
 * textToSet: the text for the textnode
 */
function setText(setTextTo, textToSet){
  removeAllChildren(setTextTo);
  newText = document.createTextNode(textToSet);
  setTextTo.appendChild(newText);
  newBreak = document.createElement("br");
  setTextTo.appendChild(newBreak);
}

/*
 * This function removes all children to a specified element
 * 
 * fromElement: the object that is to have its children removed
 */
function removeAllChildren(fromElement){
  while(fromElement.firstChild != null){
    fromElement.removeChild(fromElement.firstChild);	
  }
}

