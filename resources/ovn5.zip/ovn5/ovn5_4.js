//globala variabler
//skapa en 3x3 array, ingen data b�r lagras i gr�nssnittet
var gameArray = new Array(3); //0=ledig plats, 1 eller 2 f�r spelad ruta beroende p� spelare
gameArray[0] = new Array(3);
gameArray[1] = new Array(3);
gameArray[2] = new Array(3);
var player = 1; // 1= X, 2=O
var moveNbr = 1;
var gameOver = false;

/* returnerar true om nuvarande spelere vunnit annars false*/
function checkIfWinningMove(row, col){
  //kontrollera om alla rutor i raden d�r draget gjordes �r samma som nuvarande spelare
  if(gameArray[row][0]==player && gameArray[row][1]==player && gameArray[row][2]==player){
    gameOver=true;
    return true;
  }
  //kontrollera kolumnen om ingen vinst i raden
  else if(gameArray[0][col]==player && gameArray[1][col]==player && gameArray[2][col]==player){
    gameOver=true;
    return true;
  }
  //Kontrollera diagonalt 1
  else if(gameArray[0][0]==player && gameArray[1][1]==player && gameArray[2][2]==player){
    gameOver=true;
    return true;
  }
  //Kontrollera diagonalt 2
  else if(gameArray[2][0]==player && gameArray[1][1]==player && gameArray[0][2]==player){
    gameOver=true;
    return true;
  }
  return false; //inget vinnande drag hittades
}

function makeMove(e){
  if(gameOver){ //man ska inte kunna klicka mer n�r spelet �r vunnet
    return;
  }
  var clickedSquare;
  var eventObject= getEventObject(e);
  if(eventObject==null){
    alert("Inte tillr�ckligt st�d f�r JavaScript.");
    return;
  }
  clickedSquare = getEventTarget(eventObject);

  var mark;
  var row;
  var col;
  row = parseInt(clickedSquare.id.charAt(1));
  col = parseInt(clickedSquare.id.charAt(2));

  if(gameArray[row][col]!=0){//rutan redan klickad
    return;
  }

  removeAllChildren(clickedSquare);

  if(player==1){
    mark = "X";
  }
  else{
    mark = "O";
  }
  gameArray[row][col] = player;

  var newValue = document.createTextNode(mark);
  clickedSquare.appendChild(newValue);

  won = checkIfWinningMove(row, col);
  if(won){
  	resultElement = document.getElementById("result");
  	setText(resultElement, "Spelare "+mark+" vann!");
  }
  else if(moveNbr==9){
  	resultElement = document.getElementById("result");
  	setText(resultElement, "Spelet blev oavgjort.");
  }
  player = (player%2)+1;
  moveNbr++;
}

function resetGameArray(){
  //reset array
  for(i=0; i<gameArray.length; i++){
    for(j=0; j<gameArray[0].length; j++){
      gameArray[i][j] = 0;
      var sId = "s"+i.toString()+j.toString();
      updateTable(sId, " ");
    }
  }
}

function updateTable(squareId, value){
  square = document.getElementById(squareId);
  squareContent = square.firstChild;
  if(squareContent != null){
    square.removeChild(square.firstChild);
  }
  var newValue = document.createTextNode(value);
  square.appendChild(newValue);
}


function restartGame(){
  resetGameArray();
  player = 1;
  moveNbr = 1;
  gameOver=false;
  //ta bort meddelande och knappar i div=result
  clearElement = document.getElementById("result");
  while(clearElement.childNodes.length>0){
    clearElement.removeChild(clearElement.firstChild);
  }
}

function addListeners() {
  var button = document.getElementById("btnRestart");
  addEvent(button, "click", restartGame, false);
  var gameSqueres = document.getElementsByTagName("td");
  for(i=0; i<gameSqueres.length;i++){
    addEvent(gameSqueres[i], "click", makeMove, false)
  }
}

function initGame(){
  resetGameArray();
  addListeners();
}

addEvent(window, "load", initGame);
