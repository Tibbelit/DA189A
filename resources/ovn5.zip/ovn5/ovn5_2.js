//globala variabler
var nbr1 = 0;
var nbr2 = 0;
//var question = "";

function generateNewQuestion(){
  nbr1 = Math.floor((Math.random()*9)+1);
  nbr2 = Math.floor((Math.random()*9)+1);
  return "Hur mycket �r "+nbr1+" g�nger "+nbr2+" ?";
}
			
function checkAnswer(){
  var answer = parseInt(document.getElementById("txtAnswer").value);
  var response;
  if(answer==(nbr1*nbr2)){
    response = "Bra, det �r r�tt! F�rs�k med en ny fr�ga.";
  }
  else{
    response = "Det �r tyv�rr fel. Prova igen eller f�rs�k med en ny fr�ga.";
  }
  var insertElement = document.getElementById("result");
  setText(insertElement, response);
}

function displayNewQuestion(){
  var question = generateNewQuestion();
  var insertElement = document.getElementById("question");
  var oldQuestion = insertElement.firstChild;
  var newQuestion = document.createTextNode(question);
  insertElement.replaceChild(newQuestion, oldQuestion);
}

function addListeners() {
  var button = document.getElementById("btnCheck");
  addEvent(button, "click", checkAnswer, false);
  button = document.getElementById("btnNewQuestion");
  addEvent(button, "click", displayNewQuestion, false);
}

addEvent(window, "load", addListeners, false);
