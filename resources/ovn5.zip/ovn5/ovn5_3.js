//globala variabler
var bookings = new Array(10); //0=ledig plats, 1=bokad
var nbrSeats;
var classToBook;

//nollst�ll array d� denna inneh�ller v�rden som �r undefined annars
for(i=0; i<10; i++){
  bookings[i] = 0;
}

function freeInClass1(){
  var nbrBooked = 0;
  for(i=0; i<5; i++){
    if(bookings[i] == 0){
      nbrBooked++;
    }
  }
  return nbrBooked;
}

function freeInClass2(){
  var nbrBooked = 0;
  for(i=5; i<10; i++){
    if(bookings[i] == 0){
      nbrBooked++;
    }
  }
  return nbrBooked;
}

function firstFreeIndexInClass1(){
  var nbrBooked = 0;
  for(i=0; i<5; i++){
    if(bookings[i] == 0){
      return i;
    }
  }
  return i;
}

function firstFreeIndexInClass2(){
  var nbrBooked = 0;
  for(i=5; i<10; i++){
    if(bookings[i] == 0){
      return i;
    }
  }
  return i;
}



function updateTable(){
  for(i=0; i<10;i++){
    var insertInElement = document.getElementById("array"+i);
    currentChild = insertInElement.firstChild;
    if(bookings[i]==0){
      newText = document.createTextNode("ledig");
    }
    else{
      newText = document.createTextNode("bokad");
    }
    insertInElement.replaceChild(newText, currentChild);
  }//end for
}

function displayBookingResult(message){
  //ta bort meddelande och knappar i div=result
  clearElement = document.getElementById("result");
  removeAllChildren(clearElement);
  var resultMessage = document.createTextNode(message);
  clearElement.appendChild(resultMessage);
}

function displaySplitBookingChoise(){
  resultElement = document.getElementById("result");
  var buttonYes = document.createElement("input");
  buttonYes.type = "button";
  buttonYes.value = "Ja";
  buttonYes.id = "btnSplit";
  resultElement.appendChild(buttonYes);
  addEvent(buttonYes, "click", splitBooking, false);

  var buttonNo = document.createElement("input");
  buttonNo.type = "button";
  buttonNo.value = "Nej";
  buttonNo.id = "btnNoSplit";
  resultElement.appendChild(buttonNo);
  addEvent(buttonNo, "click", noSplitBooking, false);
}

function noSplitBooking(e){
  displayBookingResult("Ingen bokning har gjorts.");
  document.getElementById("btnBook").disabled = false;
}

function splitBooking(e){
  if(classToBook==1){
    in1st = freeInClass1();
    in2nd = nbrSeats-in1st;
    startAt = firstFreeIndexInClass1();
    for(i=startAt; i<(in1st+startAt); i++){
      bookings[i] = 1;
    }
    startAt = firstFreeIndexInClass2();
    for(i=startAt; i<(in2nd+startAt); i++){
      bookings[i] = 1;
    }
  }
  else{//boka i klass 2 f�rst
    in2nd = freeInClass2();
    in1st = nbrSeats-in2nd;
    startAt = firstFreeIndexInClass2();
    for(i=startAt; i<(in2nd+startAt); i++){
      bookings[i] = 1;
    }
    startAt = firstFreeIndexInClass1();
    for(i=startAt; i<(in1st+startAt); i++){
      bookings[i] = 1;
    }
  }//end else boka i 2 klass f�rst

  displayBookingResult("Bokningen �r f�rdelad �ver b�gge klasserna.");
  document.getElementById("btnBook").disabled = false;
  updateTable();
}

function registerBooking(){
  var couldRegister = false;
  var possibleToBook = false;
  nbrSeats = parseInt(document.getElementById("txtNbrSeats").value);
  if(document.getElementById("rdbFirst").checked){
    classToBook = 1;
  }
  else{//om inte f�rsta klass s� m�ste det vara andra klass
    classToBook = 2;
  }

  if(classToBook==1){
    if(nbrSeats<=freeInClass1()){ //kan boka i �nskad klass 1
      startAt = firstFreeIndexInClass1();
      for(i=startAt; i<(nbrSeats+startAt); i++){
        bookings[i] = 1;
      }
      couldRegister = true;
      }
    else{ //ej tillr�ckligt med platser i f�rsta
      in1st = freeInClass1();
      in2nd = nbrSeats-in1st;
      possibleToBook = (in2nd<=freeInClass2()); //true om platser finns annars false
    }//end else ej tillr�ckligt med platser i f�rsta
  }//end if boka i 1 klass
  else { //boka i 2 klass
    if(nbrSeats<=freeInClass2()){
      startAt = firstFreeIndexInClass2();
      for(i=startAt; i<(nbrSeats+startAt); i++){
        bookings[i] = 1;
      }
      couldRegister = true;
    }
    else{ //ej tillr�ckligt med platser i andra
      in2nd = freeInClass2();
      in1st = nbrSeats-in2nd;
      possibleToBook = (in1st<=freeInClass1());
    }
  }//end
  if(couldRegister){//kunde boka �nskat antal i �nskad klass
    displayBookingResult("Bokningen �r genomf�rd.");
    updateTable();
  }
  else if(possibleToBook){//kan boka �nskat antal men inte alla i �nskad klass
    var message;
    if(classToBook ==1){
      message = "Alla fick inte plats i f�rsta klass. Vill du boka resten i andra klass?";
    }
    else{
      message = "Alla fick inte plats i andra klass. Vill du boka resten i f�rsta klass?";
    }
    displayBookingResult(message);
    displaySplitBookingChoise()
    document.getElementById("btnBook").disabled = true;
  }// end else if(possibleToBook){//kan boka �nskat antal men inte alla i �nskad klass
  else{ //f�r f� platser f�r bokning
    displayBookingResult("Bokningen kunde inte genomf�ras d� f�r f� platser var lediga.");
  }
} //end function register booking

function addListeners() {
  var button = document.getElementById("btnBook");
  addEvent(button, "click", registerBooking, false);
}

addEvent(window, "load", addListeners, false);