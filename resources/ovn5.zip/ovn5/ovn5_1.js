function integerPower(base, exponent){
  var result = 1;
  for(i=0;i<exponent; i++){
    result *= base;
  }
  return result;
}

function computePowerOf(){
  var insertElement = document.getElementById("result");
  var base = parseInt(document.getElementById("txtBase").value);
  var exp = parseInt(document.getElementById("txtExp").value);
  if(isNaN(base) || isNaN(exp)){
    setText(insertElement, "Ber�kningen kan endast ske p� talv�rden");
  }
  else{
    var result = integerPower(base, exp);
    setText(insertElement, base+" upph�jt med "+exp+" �r "+result);
  }
}

function addListeners() {
  var button = document.getElementById("btnCompute");
  addEvent(button, "click", computePowerOf, false);
}

//Anv�nd egen funktion f�r load...
addEvent(window, "load", addListeners, false);